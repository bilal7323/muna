package com.cyunrei.videolivewallpaper;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.VideoView;



import java.io.File;


public class PreviewWallpaperActivity extends AppCompatActivity {
    /* access modifiers changed from: private */
    public Context context;
    /* access modifiers changed from: private */
    public String b;
    /* access modifiers changed from: private */
    public String c;
    private boolean d = true;
    /* access modifiers changed from: private */
    public VideoView e;
    /* access modifiers changed from: private */
    public MediaPlayer f;
    Bundle bundle2;

    /* access modifiers changed from: protected */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);
        this.context = this;
        TextView textView = findViewById(R.id.tv_video_suggestion);
        this.c = "1";
        bundle2 = getIntent().getExtras();
        if (bundle2 != null) {
            this.b = bundle2.getString("photoPath");
            if (this.b != null) {
                if (this.b.endsWith(".mp4") || this.b.endsWith(".MP4") || this.b.endsWith(".avi") || this.b.endsWith(".AVI") || this.b.endsWith(".flv") || this.b.endsWith(".FLV") || this.b.endsWith(".3gp") || this.b.endsWith(".3GP")) {
                    try {
                        MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
                        mediaMetadataRetriever.setDataSource(this.context, Uri.parse(this.b));
                        this.d = a(mediaMetadataRetriever.extractMetadata(18), mediaMetadataRetriever.extractMetadata(19), mediaMetadataRetriever.extractMetadata(24));
                        if (!this.d) {
                            textView.setVisibility(View.GONE);
                            this.c = "2";
                        }
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                    this.e = findViewById(R.id.view_video);
                    this.e.setVisibility(View.GONE);
                    this.e.setOnPreparedListener(new OnPreparedListener() {
                        public void onPrepared(MediaPlayer mediaPlayer) {
                            PreviewWallpaperActivity.this.f = mediaPlayer;
                            PreviewWallpaperActivity.this.e.start();
                        }
                    });
                    this.e.setOnErrorListener(new OnErrorListener() {
                        public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                            PreviewWallpaperActivity.this.e.stopPlayback();
                            PreviewWallpaperActivity.this.e.setBackgroundColor(PreviewWallpaperActivity.this.context.getResources().getColor(R.color.black));
                            return true;
                        }
                    });
                    this.e.setVideoURI(Uri.fromFile(new File(this.b)));
                    this.e.setOnCompletionListener(new OnCompletionListener() {
                        public void onCompletion(MediaPlayer mediaPlayer) {
                            mediaPlayer.start();
                            mediaPlayer.setLooping(true);
                        }
                    });
                } else {
                    ImageView imageView = findViewById(R.id.view_image);
                    imageView.setVisibility(View.GONE);
                    imageView.setImageURI(Uri.fromFile(new File(this.b)));
                }
            }
        } else {
            this.b = null;
        }
        final Switch switchCompat = findViewById(R.id.setting_volume);
        switchCompat.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (PreviewWallpaperActivity.this.f == null) {
                    return;
                }
                if (z) {
                    PreviewWallpaperActivity.this.f.setVolume(1.0f, 1.0f);
                } else {
                    PreviewWallpaperActivity.this.f.setVolume(0.0f, 0.0f);
                }
            }
        });
        Switch switchCompat2 = findViewById(R.id.setting_scale);
        switchCompat2.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (PreviewWallpaperActivity.this.f == null) {
                    return;
                }
                if (z) {
                    PreviewWallpaperActivity.this.c = "1";
                    PreviewWallpaperActivity.this.f.setVideoScalingMode(1);
                    return;
                }
                PreviewWallpaperActivity.this.c = "2";
                PreviewWallpaperActivity.this.f.setVideoScalingMode(2);
            }
        });
        if (!this.d) {
            switchCompat2.setChecked(false);
        }
        final Switch switchCompat3 = findViewById(R.id.setting_doubleclick_pause);
        switchCompat3.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                PreviewWallpaperActivity.this.a(z);
            }
        });
        switchCompat3.setChecked(a());
        findViewById(R.id.button_set_wallpaper).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (b != null) {
                    PreviewWallpaperActivity previewWallpaperActivity = PreviewWallpaperActivity.this;
                    previewWallpaperActivity.a(previewWallpaperActivity.b, switchCompat.isChecked(), PreviewWallpaperActivity.this.c);
                    a(switchCompat3.isChecked());
                    finish();
                }
            }
        });
        findViewById(R.id.btn_back).setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                finish();
            }
        });

    }

    /* access modifiers changed from: private */
    public void a(boolean z) {
        Editor edit = getSharedPreferences("VideoWallpaper", MODE_PRIVATE).edit();
        edit.putBoolean("pref_double_tap_start_stop_video", z);
        edit.apply();
    }

    private boolean a() {
        return getSharedPreferences("VideoWallpaper", MODE_PRIVATE).getBoolean("pref_double_tap_start_stop_video", false);
    }

    private boolean a(String str, String str2, String str3) {
        if (str == null || str2 == null || str3 == null) {
            return false;
        }
        float f2 = 0.75f;
        if (str3.equals("0") || str3.equals("180")) {
            f2 = ((float) Integer.parseInt(str)) / ((float) Integer.parseInt(str2));
        } else if (str3.equals("90") || str3.equals("270")) {
            f2 = ((float) Integer.parseInt(str2)) / ((float) Integer.parseInt(str));
        }
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(f2);
        Log.e("test", sb.toString());
        return !(f2 > 1.0f);
    }

    /* access modifiers changed from: private */
    public void a(String str, boolean z, String str2) {
        c = str;
        d = z;
        b = str2;

    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        if (this.b != null) {
            VideoView videoView = findViewById(R.id.view_video);
            videoView.setVisibility(View.GONE);
            try {
                videoView.setVideoURI(Uri.fromFile(new File(this.b)));
                videoView.start();
            } catch (Exception unused) {
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        b();
    }

    private void b() {
        try {
            ((VideoView) findViewById(R.id.view_video)).stopPlayback();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }
}
